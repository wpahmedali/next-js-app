# Icons

The icon library

## Usage

Place your svg icons in the `icons` directory and then run the build command to generate the React icon components.

```bash
yarn build
```
