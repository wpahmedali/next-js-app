export interface ISearchByChassissNumber {
  country_id: number;
  keyword: string;
}
