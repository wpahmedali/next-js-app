export interface IEnquriryParamData {
  car_id: number;
  subject: string;
  name: string;
  countryName: string;
  city: string;
  email: string;
  phone: string;
  whatsapp_phone: string;
  remarks: string;
  action: string;
}

export interface IRatings {
  color: string;
  rank: number;
}
