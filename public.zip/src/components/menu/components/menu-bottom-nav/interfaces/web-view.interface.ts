export interface IWebView {
  showMobileMenu: () => void;
}
