import { IDropdownData } from './dropdown-data.interface';

export interface IDropdown {
  data: IDropdownData;
  title: string;
  tabName?: string;
}
