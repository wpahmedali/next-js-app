export interface IMobileView {
  mobileMenuOpen: any;
  setMobileMenuOpen: (value: any) => void;
}
