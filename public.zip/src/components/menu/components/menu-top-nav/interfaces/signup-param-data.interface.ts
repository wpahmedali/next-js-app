export interface ISignupParamData {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  password: string;
  c_password: string;
}
