export interface ILoginParamData {
  email: string;
  password: string;
}
