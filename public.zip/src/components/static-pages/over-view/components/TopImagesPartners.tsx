import Image from 'next/image';

const TopImagesPartners = () => {
  return (
    
<Image className="h-auto max-w-full" src="/asset/images/profile/partner-banner.png" alt=".." width={1920} height={409} />

  );
};
export default TopImagesPartners;


