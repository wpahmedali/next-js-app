export interface ITyreAuctionButton {
  url: string;
  loadingtype: string;
  name: string;
  date: string;
  time?: string;
}
