import React from 'react';

const RightSidebar = () => {
  return (
    <div className="xxs:w-full xs:w-full sm:w-full 2xl:w-[375px] xl:w-[375px] lg:w-[375px] md:w-[300px] flex-col z-30">
      <div className="w-full"></div>
    </div>
  );
};

export default RightSidebar;
