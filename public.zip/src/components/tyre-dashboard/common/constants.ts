export const zambiaCountry = Object.freeze({
  id: 12,
  name: 'zambia',
});

export const sharjahCountry = Object.freeze({
  id: 17,
  name: 'sharjah',
});
