import { ITyreDetail } from 'src/interfaces/tyres/zambia/tyre-detail.interface';

export interface ITyreListingCard {
  isEven: boolean;
  data: ITyreDetail;
}
