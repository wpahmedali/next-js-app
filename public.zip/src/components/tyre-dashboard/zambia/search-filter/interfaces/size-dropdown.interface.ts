import { ITyreSize } from 'src/interfaces/tyres/zambia/tyre-size.interface';

export interface ISizeDropdown extends ITyreSize {
  isChecked: boolean;
}
