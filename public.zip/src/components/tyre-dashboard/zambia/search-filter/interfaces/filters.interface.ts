export interface ITyreFilters {
  tyreSizeId: number;
  keyWord: string;
}
