import { ITyreAddress } from 'src/interfaces/tyres/zambia/tyre-address.interface';

export interface ILocationCard {
  isEven: boolean;
  data: ITyreAddress;
}
