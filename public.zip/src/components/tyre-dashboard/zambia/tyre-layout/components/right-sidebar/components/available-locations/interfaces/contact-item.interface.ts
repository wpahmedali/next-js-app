export interface IContactItem {
  title: string;
  value: string;
  image: string;
}
