export interface IDropdownData {
  id: number;
  name: string;
  image?: string;
  isChecked: boolean;
}
