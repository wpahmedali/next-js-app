export interface IFilters {
  makers: string[];
  models: string[];
  steerings: string[];
  trans: string[];
  fuel: string[];
  minYear: string[];
  maxYear: string[];
  bodyTypes: string[];
  stockNo: string;
  chassisNo: string;
}
