import React from 'react';

const Error = (): JSX.Element => (
  <div className="py-5 text-center text-red-500">Something went wrong!</div>
);

export default Error;
