export interface ISeeMoreButton {
  isLoading: boolean;
  seeMore: () => void;
}
