export interface ICloseIcon {
  hideDialog: (type: string) => void;
  setAllErrors?: any;
  setFormData?: any;
}
