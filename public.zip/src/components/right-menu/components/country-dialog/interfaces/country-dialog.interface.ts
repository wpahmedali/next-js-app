export interface ICountryDialog {
  isShowDialog: string;
  hideDialog: (type: string) => void;
}
