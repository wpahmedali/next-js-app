import React from 'react';
import WebBodyTypes from './components/WebBodyType';

const BodyTypes = () => {
  return <WebBodyTypes />;
};

export default BodyTypes;
