export interface IPaginationButton {
  handleButtonClick: () => void;
  page: number;
  isActive: boolean;
}
