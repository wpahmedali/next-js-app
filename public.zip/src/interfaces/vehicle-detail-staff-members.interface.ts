export interface IVehicleDetailStaffMember {
  memberDesignation: string;
  memberImg: string;
  memberName: string;
  memberPhone: string;
}
