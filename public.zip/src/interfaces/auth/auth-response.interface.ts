export interface IAuthResponse {
  token: string;
  id: number;
  name: string;
  email: string;
  phone: string;
  image: string;
}
