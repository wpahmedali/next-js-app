export interface INextPreviousVehicleList {
  carId: number;
}
