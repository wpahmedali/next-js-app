export interface ISteering {
  steeringId: number;
  steeringName: string;
}
