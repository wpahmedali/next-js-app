export interface ITyreCategory {
  tyreCatId: number;
  categoryName: string;
  mainCategoryCount: string;
}
