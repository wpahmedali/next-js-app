export interface ITyreSize {
  tyreSizeId: number;
  sizeName: string;
}
