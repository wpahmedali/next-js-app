export interface ITyreAddress {
  id: number;
  city: string;
  phone: string;
  email: string;
  address: string;
  cityId: number;
  country: string;
  countryId: number;
}
