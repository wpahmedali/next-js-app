export interface ITyreLatestAuction {
  auctionId: number;
  auctionName: string;
  auctionDate: string;
  flagIcon: string;
  soldImage: string;
}
