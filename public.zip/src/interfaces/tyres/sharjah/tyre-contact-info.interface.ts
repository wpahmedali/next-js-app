export interface ITyreContactInfo {
  area: string;
  building: string;
  furtheraddress: string;
  googleMap: string;
}
