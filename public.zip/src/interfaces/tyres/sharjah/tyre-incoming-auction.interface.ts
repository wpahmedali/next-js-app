export interface ITyreIncomingAuction {
  id: number;
  auctionName: string;
  date: string;
  time: string;
  flagIcon: string;
}
