export interface ISoldTyreDetail {
  transId: number;
  auctionId: number;
  lotNo: number;
  tyreSize: string;
  qty: number;
  price: number;
  amount: number;
  auctionName: string;
  auctionDate: string;
}
