export interface IVehicleDetailStandardFeatures {
  accessoriesName: string;
  shortName: string;
}
