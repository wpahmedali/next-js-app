export interface IAuction {
  auctionId: number;
  auctionShortName: string;
  auctionName: string;
  auctionDate: string;
  soldStatus: number;
  carsCount: number;
}
