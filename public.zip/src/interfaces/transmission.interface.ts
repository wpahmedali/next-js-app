export interface ITransmission {
  transmissionId: number;
  transmissionName: string;
}
