export interface IFuel {
  fuelId: number;
  fuelName: string;
}
