export interface IBodyType {
  bodyTypeId: number;
  bodyTypeName: string;
  cssClass: string;
  bodyTypeCount: number;
}
