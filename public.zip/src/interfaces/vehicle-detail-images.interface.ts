export interface IVehicleDetailImage {
  carId: number;
  carImageId: number;
  directory: string;
  fileName: string;
  imagePath: string;
  isAuctionSheet?: number;
}
