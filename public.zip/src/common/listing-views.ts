export const listingViews = Object.freeze({ grid: 'grid', tabular: 'tabular' });
